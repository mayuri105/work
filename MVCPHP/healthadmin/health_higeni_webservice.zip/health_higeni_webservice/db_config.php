<?php

/*
 * All database connection variables
 */

define('DB_USER', "mdollar_health"); // db user
define('DB_PASSWORD', "health"); // db password (mention your db password here)
define('DB_DATABASE', "mdollar_health_higen"); // database name
define('DB_SERVER', "localhost"); // db server
?>