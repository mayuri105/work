<html>
<head>
<title> Custom Form Kit </title>
</head>
<body>
<center>

<?php require_once('resources/views/admin/onlinepayment/Crypto.blade.php')?>
<?php

	error_reporting(0);

	$merchant_data='252857';
	$working_key='C8870A272402CA4E519AF08A3081E079';//Shared by CCAVENUES
	$access_code='AVQW91HC18BN11WQNB';//Shared by CCAVENUES
	//echo"<pre>";print_r($input);die;

	foreach ($input as $key => $value){

		$merchant_data.=$key.'='.urlencode($value).'&';
	}

	$encrypted_data=encrypt($merchant_data,$working_key);
//echo"<pre>";print_r($encrypted_data);die;	// Method for encrypting the data.

?>
<form method="post" name="redirect" action="{{url('https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction')}}">
<?php
echo "<input type=hidden name=encRequest value=$encrypted_data>";
echo "<input type=hidden name=access_code value=$access_code>";
?>
</form>
</center>
<script language='javascript'>document.redirect.submit();</script>
</body>
</html>

