<?php
/**
 * Cmsmart Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0).
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you are unable to obtain it through the world-wide-web, please send
 * an email to info@Cmsmart.com so we can send you a copy immediately.
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @copyright  Copyright (c) 2010-2012 Cmsmart Co. 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Edit form block for recipes
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @author     VF 
 */
class Cmsmart_Recipes_Block_Adminhtml_Recipes_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{

    /**
     * Preparing global layout
     *
     * You can redefine this method in child classes for changin layout
     *
     * @return Mage_Core_Block_Abstract
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        if (Mage::getSingleton('cms/wysiwyg_config')->isEnabled()) {
            $this->getLayout()->getBlock('head')->setCanLoadTinyMce(true);
        }
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return Mage_Adminhtml_Block_Widget_Form
     */
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form(array(
            'id' => 'edit_form',
            'action' => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
            'method' => 'post',
            'enctype' => 'multipart/form-data'
        ));

        $fieldset = $form->addFieldset('recipes_form', array(
            'legend'	  => Mage::helper('cmsmart_recipes')->__('Recipes'),
            'class'		=> 'fieldset-wide',
            )
        );

        $fieldset->addField('recipes_position', 'text', array(
            'name'      => 'recipes_position',
            'label'     => Mage::helper('cmsmart_recipes')->__('Position'),
            'style'     => 'width:100px !important',
        ));
        $outputFormat = Mage::app()->getLocale()->getDateTimeFormat(Mage_Core_Model_Locale::FORMAT_TYPE_MEDIUM);
        	$fieldset->addField('date', 'date',array(
        			'name'      =>    'date',
        			'time'      =>    true,
        			'format'    =>    $outputFormat,
        			'label'     =>    Mage::helper('cmsmart_recipes')->__('Post Date'),
        			'image'     =>    $this->getSkinUrl('images/grid-cal.gif')
       		));
        $fieldset->addField('recipes_img', 'image', array(
            'name'      => 'recipes_img',
            'label'     => Mage::helper('cmsmart_recipes')->__('Image'),
        ));

        $fieldset->addField('recipes_name', 'text', array(
            'name'      => 'recipes_name',
            'label'     => Mage::helper('cmsmart_recipes')->__('Title'),
            'class'     => 'required-entry',
            'required'  => true,
        ));

        $fieldset->addField('recipes_text', 'editor', array(
            'name'      => 'recipes_text',
            'label'     => Mage::helper('cmsmart_recipes')->__('Content'),
            'title'     => Mage::helper('cmsmart_recipes')->__('Text'),
            'style'     => 'width:100%;height:300px;',
            'required'  => true,
            'config'    => Mage::getSingleton('cmsmart_recipes/wysiwyg_config')->getConfig()
        ));

        $fieldset->addField('recipes_sidebar', 'select', array(
            'label'     => Mage::helper('cmsmart_recipes')->__('Show in sidebox'),
            'name'      => 'recipes_sidebar',
            'values'    => array(
                array(
                    'value'     => 1,
                    'label'     => Mage::helper('core')->__('Yes'),
                ),
                array(
                    'value'     => 0,
                    'label'     => Mage::helper('core')->__('No'),
                ),
            ),
        ));

        if (Mage::registry('cmsmart_recipes')) {
            $form->setValues(Mage::registry('cmsmart_recipes')->getData());
        }

        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }

}
