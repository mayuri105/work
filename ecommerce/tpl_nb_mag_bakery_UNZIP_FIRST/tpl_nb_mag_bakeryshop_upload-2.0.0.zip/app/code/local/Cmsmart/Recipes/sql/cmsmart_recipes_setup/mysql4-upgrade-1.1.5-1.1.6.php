<?php
/**
 * Cmsmart Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0).
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you are unable to obtain it through the world-wide-web, please send
 * an email to info@Cmsmart.com so we can send you a copy immediately.
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @copyright  Copyright (c) 2010-2012 Cmsmart Co. 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Upgrade script 1.1.1 -> 1.1.2
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @author     VF 
 */

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;
//die;
$installer->startSetup();

$connection = $installer->getConnection();
$table='cmsmart_recipes';

$connection->addColumn($installer->getTable($table), 'date', array(
        'type'      => Varien_Db_Ddl_Table::TYPE_DATE,
        'comment'   => 'Date',
    ));

$installer->endSetup();
