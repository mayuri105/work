<?php
/**
 * Cmsmart Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0).
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you are unable to obtain it through the world-wide-web, please send
 * an email to info@cmsmart.com so we can send you a copy immediately.
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @copyright  Copyright (c) 2010-2012 Cmsmart Co. 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Edit form block container for recipes
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @author     VF 
 */
class Cmsmart_Recipes_Block_Adminhtml_Recipes_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();

        $this->_objectId = 'id';
        $this->_blockGroup = 'cmsmart_recipes';
        $this->_controller = 'adminhtml_recipes';

        $this->_updateButton('save', 'label', Mage::helper('cmsmart_recipes')->__('Save Recipes'));
        $this->_updateButton('delete', 'label', Mage::helper('cmsmart_recipes')->__('Delete Recipes'));

        if( $this->getRequest()->getParam($this->_objectId) ) {
            $model = Mage::getModel('cmsmart_recipes/recipes')->load($this->getRequest()->getParam($this->_objectId));
            Mage::register('cmsmart_recipes', $model);
        }
    }

    /**
     * Get header text
     *
     * @return string
     */
    public function getHeaderText()
    {
        if( Mage::registry('cmsmart_recipes') && Mage::registry('cmsmart_recipes')->getId() ) {
            return Mage::helper('cmsmart_recipes')->__('Edit Recipes');
        } else {
            return Mage::helper('cmsmart_recipes')->__('Add Recipes');
        }
    }
}
