<?php
/**
 * cmsmart Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0).
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you are unable to obtain it through the world-wide-web, please send
 * an email to info@Cmsmart.com so we can send you a copy immediately.
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @copyright  Copyright (c) 2010-2012 Cmsmart Co. 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Grid block for recipes
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @author     VF 
 */
class Cmsmart_Recipes_Block_Adminhtml_Recipes_Grid extends Mage_Adminhtml_Block_Widget_Grid
{

    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId('recipesGrid');
        $this->setDefaultSort('recipes_position');
        $this->setDefaultDir('ASC');
        $this->setSaveParametersInSession(true);
    }

    /**
     * Prepare grid collection object
     *
     * @return Cmsmart_Recipes_Block_Adminhtml_Recipes_Grid
     */
    protected function _prepareCollection()
    {
        $this->setCollection(Mage::getModel('cmsmart_recipes/recipes')->getCollection());
        return parent::_prepareCollection();
    }

    /**
     * Preparing colums for grid
     *
     * @return cmsmart_Recipes_Block_Adminhtml_Recipes_Grid
     */
    protected function _prepareColumns()
    {
        $this->addColumn('recipes_position', array(
            'header'    => Mage::helper('cmsmart_recipes')->__('Position'),
            'align'     => 'right',
            'width'     => '50px',
            'index'     => 'recipes_position',
            'type'      => 'number',
        ));

        $this->addColumn('recipes_name', array(
            'header'    => Mage::helper('cmsmart_recipes')->__('Name'),
            'align'     => 'left',
            'index'     => 'recipes_name',
        ));

        $this->addColumn('recipes_text', array(
            'header'    => Mage::helper('cmsmart_recipes')->__('Text'),
            'align'     => 'left',
            'index'     => 'recipes_text',
        ));

        return parent::_prepareColumns();
    }

    public function getRowUrl($row)
    {
        return $this->getUrl('*/*/edit', array('id' => $row->getId()));
    }

}
