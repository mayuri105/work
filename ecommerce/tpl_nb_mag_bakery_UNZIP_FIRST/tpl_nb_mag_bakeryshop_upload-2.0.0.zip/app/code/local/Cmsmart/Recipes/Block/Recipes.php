<?php
/**
 * Cmsmart Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0).
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you are unable to obtain it through the world-wide-web, please send
 * an email to info@Cmsmart.com so we can send you a copy immediately.
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @copyright  Copyright (c) 2010-2012 Cmsmart Co. 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Frontend block for recipes
 *
 * @method Cmsmart_Recipes_Model_Mysql4_Recipes_Collection getRecipes()
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @author     VF 
 */
class Cmsmart_Recipes_Block_Recipes extends Mage_Core_Block_Template
{

    /**
     * Before rendering html, but after trying to load cache
     *
     * @return Cmsmart_Recipes_Block_Recipes
     */
    protected function _beforeToHtml()
    {
        $this->_prepareCollection();
        return parent::_beforeToHtml();
    }

    /**
     * Prepare recipes collection object
     *
     * @return Cmsmart_Recipes_Block_Recipes
     */
    protected function _prepareCollection()
    {
        /* @var $collection Cmsmart_Recipes_Model_Mysql4_Recipes_Collection */
        $collection = Mage::getModel("cmsmart_recipes/recipes")->getCollection();
        if ($this->getSidebar()){
            $collection->addFieldToFilter('recipes_sidebar', '1');
        }

        $collection->setOrder('recipes_position', 'ASC')
                   ->load();
        $this->setRecipes($collection);
        return $this;
    }

}