<?php
/**
 * Cmsmart Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0).
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you are unable to obtain it through the world-wide-web, please send
 * an email to info@Cmsmart.com so we can send you a copy immediately.
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @copyright  Copyright (c) 2010-2012 Cmsmart Co. 
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Recipes admin controller (view, edit)
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @author     VF 
 */
class Cmsmart_Recipes_Adminhtml_RecipesController extends Mage_Adminhtml_Controller_Action
{

    /**
     * Init here
     */
	protected function _initAction()
	{
		$this->loadLayout();
		$this->_setActiveMenu('cms/recipes');
		$this->_addBreadcrumb(Mage::helper('cmsmart_recipes')->__('Recipes'), Mage::helper('cmsmart_recipes')->__('Recipes'));
	}

    /**
     * View grid action
     */
	public function indexAction()
	{
		$this->_initAction();
		$this->renderLayout();
	}

    /**
     * View edit form action
     */
	public function editAction()
	{
		$this->_initAction();
		$this->_addContent($this->getLayout()->createBlock('cmsmart_recipes/adminhtml_recipes_edit'));
		$this->renderLayout();
	}

    /**
     * View new form action
     */
	public function newAction()
	{
		$this->editAction();
	}

    /**
     * Save form action
     */
	public function saveAction()
	{
		if ($this->getRequest()->getPost()) {
			try {
				$data = $this->getRequest()->getPost();
				if (isset($_FILES['recipes_img']['name']) and (file_exists($_FILES['recipes_img']['tmp_name']))) {
					$uploader = new Varien_File_Uploader('recipes_img');
					$uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
					$uploader->setAllowRenameFiles(false);
					$uploader->setFilesDispersion(false);
					$path = Mage::getBaseDir('media') . DS ;
					$uploader->save($path, $_FILES['recipes_img']['name']);
					$data['recipes_img'] = $_FILES['recipes_img']['name'];
				} else {
					if(isset($data['recipes_img']['delete']) && $data['recipes_img']['delete'] == 1) {
						$data['recipes_img'] = '';
					} else {
						unset($data['recipes_img']);
					}
				}
				//print_r($data);die;
				$model = Mage::getModel('cmsmart_recipes/recipes');
				$model->setData($data)->setRecipesId($this->getRequest()->getParam('id'))->save();

				Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('cmsmart_recipes')->__('Recipes was successfully saved'));
			} catch (Exception $e) {
				Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
				$this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
				return;
			}
		}

		$this->_redirect('*/*/');
	}

    /**
     * Delete action
     */
	public function deleteAction()
	{
		if ($this->getRequest()->getParam('id') > 0) {
			try {
				$model = Mage::getModel('cmsmart_recipes/recipes');
				$model->setRecipesId($this->getRequest()->getParam('id'))
				      ->delete();
				Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('cmsmart_recipes')->__('Recipes was successfully deleted'));
				$this->_redirect('*/*/');
			} catch (Exception $e) {
				Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
				$this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
			}
		}

		$this->_redirect('*/*/');
	}

    /**
     * Check allow or not access to ths page
     *
     * @return bool - is allowed to access this menu
     */
	protected function _isAllowed()
	{
		return Mage::getSingleton('admin/session')->isAllowed('cms/recipes');
	}

}
