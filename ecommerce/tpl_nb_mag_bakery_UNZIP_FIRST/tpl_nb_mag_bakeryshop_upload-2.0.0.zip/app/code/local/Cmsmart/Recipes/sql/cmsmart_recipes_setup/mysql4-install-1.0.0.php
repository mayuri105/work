<?php
/**
 * Cmsmart Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0).
 * It is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you are unable to obtain it through the world-wide-web, please send
 * an email to info@Cmsmart.com so we can send you a copy immediately.
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @copyright  Copyright (c) 2010-2012 Cmsmart Co.
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Installation script
 *
 * @category   Cmsmart
 * @package    Cmsmart_Recipes
 * @author     VF 
 */

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;

$installer->startSetup();

$table = $installer->getTable('recipes');

$installer->run("
    create table IF NOT EXISTS {$table} (
        recipes_id int(11) unsigned not null auto_increment,
        recipes_position int(11) default 0,
        recipes_name varchar(50) not null default '',
        recipes_text text not null default '',
        recipes_img varchar(128) default NULL,
        recipes_sidebar tinyint(4) NOT NULL,
        PRIMARY KEY(recipes_id)
    ) engine=InnoDB default charset=utf8;
");

$installer->endSetup();
