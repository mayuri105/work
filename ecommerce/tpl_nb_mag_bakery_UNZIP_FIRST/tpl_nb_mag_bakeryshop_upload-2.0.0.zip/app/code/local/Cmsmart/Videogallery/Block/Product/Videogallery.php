<?php
/*------------------------------------------------------------------------
* Magento Extension Video Gallery
* author: The Cmsmart Development Team 
* copyright Copyright (C) 2013 www.cmsmart.net All Rights Reserved.
* @license - http://opensource.org/licenses/AFL-3.0  AFL
* Websites: www.cmsmart.net
* Technical Support: Forum - www.cmsmart.net/support
-------------------------------------------------------------------------*/

class Cmsmart_Videogallery_Block_Product_Videogallery extends Mage_Catalog_Block_Product_View
{
	 
	protected $_videogalleryCollection;
	 
    public function getVideogallerysCollection($product)
    {
    	if($product)
    	{
    		$productVideogallerys = $product->getVideogallery();
    	  	$pos = strpos($productVideogallerys,',');
    		if ($pos === false)  
    		{
    			 
    			 $this->_videogalleryCollection[] = Mage::getModel('videogallery/videogallery')->getCollection()  
				                			->addFieldToFilter('videogallery_id', $productVideogallerys);
	   		} else {
    			
    			$arrProductVideogallerys = explode(',',$productVideogallerys);  
				foreach ($arrProductVideogallerys as $awId)
				{
					  $this->_videogalleryCollection[] = Mage::getModel('videogallery/videogallery')->getCollection()  
		                ->addFieldToFilter('videogallery_id', $awId); 
				}           
    		}
 
    	}
    
        return $this->_videogalleryCollection;
    }
}