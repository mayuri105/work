<?php
/*------------------------------------------------------------------------
* Magento Extension Video Gallery
* author: The Cmsmart Development Team 
* copyright Copyright (C) 2013 www.cmsmart.net All Rights Reserved.
* @license - http://opensource.org/licenses/AFL-3.0  AFL
* Websites: www.cmsmart.net
* Technical Support: Forum - www.cmsmart.net/support
-------------------------------------------------------------------------*/

class Cmsmart_Videogallery_Helper_Data extends Mage_Core_Helper_Abstract
{
      

}