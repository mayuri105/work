<?php
/*------------------------------------------------------------------------
* Magento Extension Video Gallery
* author: The Cmsmart Development Team 
* copyright Copyright (C) 2013 www.cmsmart.net All Rights Reserved.
* @license - http://opensource.org/licenses/AFL-3.0  AFL
* Websites: www.cmsmart.net
* Technical Support: Forum - www.cmsmart.net/support
-------------------------------------------------------------------------*/

    class Cmsmart_Videogallery_Block_Adminhtml_Videogallery_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
    {
        protected function _prepareForm()
        {
            $form = new Varien_Data_Form(array(
                                            'id' => 'edit_form',
                                            'action' => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
                                            'method' => 'post',
                                            'enctype'   =>  'multipart/form-data',
                                         )
            );
     
            $form->setUseContainer(true);
            $this->setForm($form);
            return parent::_prepareForm();
        }
    }