<?php
/*------------------------------------------------------------------------
* Magento Extension Video Gallery
* author: The Cmsmart Development Team 
* copyright Copyright (C) 2013 www.cmsmart.net All Rights Reserved.
* @license - http://opensource.org/licenses/AFL-3.0  AFL
* Websites: www.cmsmart.net
* Technical Support: Forum - www.cmsmart.net/support
-------------------------------------------------------------------------*/
	 
    $installer = $this;
    $installer->startSetup();
    $installer->run("
    DROP TABLE IF EXISTS {$this->getTable('videogallery')};
	CREATE TABLE {$this->getTable('videogallery')} (
     `videogallery_id` int(11) unsigned NOT NULL auto_increment,
     `videogallery_category` varchar(200) NOT NULL default '',
	 `videogallery_url` varchar(500) NOT NULL default '',
     `position` int(11) NOT NULL default '0',
     `date` datetime NOT NULL ,
     `name` varchar(255) NOT NULL default '',
	 `image` varchar(255) NOT NULL default '',
	 `gallery_image` varchar(255) NOT NULL default '',
	 PRIMARY KEY (`videogallery_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;   
	");
 	$installer->endSetup();
