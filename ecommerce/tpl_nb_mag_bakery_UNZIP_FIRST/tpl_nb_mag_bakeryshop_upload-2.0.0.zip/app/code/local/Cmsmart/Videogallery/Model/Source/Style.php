<?php
/*------------------------------------------------------------------------

* Magento Extension Video Gallery

* author: The Cmsmart Development Team 

* copyright Copyright (C) 2013 www.cmsmart.net All Rights Reserved.

* @license - http://opensource.org/licenses/AFL-3.0  AFL

* Websites: www.cmsmart.net

* Technical Support: Forum - www.cmsmart.net/support

-------------------------------------------------------------------------*/

class Cmsmart_Videogallery_Model_Source_Style
{
  public function toOptionArray()
  {
    return array(
      array('value' => 0, 'label' =>'Horizontal'),
      array('value' => 1, 'label' =>'Vertical'),     
    );
  }
}
