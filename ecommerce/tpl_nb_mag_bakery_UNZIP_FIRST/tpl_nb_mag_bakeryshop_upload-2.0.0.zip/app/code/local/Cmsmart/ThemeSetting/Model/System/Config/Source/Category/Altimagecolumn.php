<?php

class Cmsmart_ThemeSetting_Model_System_Config_Source_Category_AltImageColumn
{
    public function toOptionArray()
    {
        return array(
			array('value' => 'label',			'label' => Mage::helper('themesetting')->__('Image Label')),
            array('value' => 'position',		'label' => Mage::helper('themesetting')->__('Image Sort Order Value'))
        );
    }
}