<?php

class Cmsmart_ThemeSetting_Model_System_Config_Source_Element_Display
{
    public function toOptionArray()
    {
		return array(
			array('value' => 0, 'label' => Mage::helper('themesetting')->__('Don\'t Display')),
            array('value' => 1, 'label' => Mage::helper('themesetting')->__('Display On Hover')),
            array('value' => 2, 'label' => Mage::helper('themesetting')->__('Display'))
        );
    }
}