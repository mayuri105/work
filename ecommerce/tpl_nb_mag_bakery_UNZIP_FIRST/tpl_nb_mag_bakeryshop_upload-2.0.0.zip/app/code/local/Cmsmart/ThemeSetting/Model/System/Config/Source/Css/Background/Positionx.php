<?php

class Cmsmart_ThemeSetting_Model_System_Config_Source_Css_Background_Positionx
{
    public function toOptionArray()
    {
		return array(
			array('value' => 'left',	'label' => Mage::helper('themesetting')->__('left')),
            array('value' => 'center',	'label' => Mage::helper('themesetting')->__('center')),
            array('value' => 'right',	'label' => Mage::helper('themesetting')->__('right'))
        );
    }
}