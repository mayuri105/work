<?php

class Cmsmart_ThemeSetting_Model_System_Config_Source_Css_Background_Repeat
{
    public function toOptionArray()
    {
		return array(
			array('value' => 'no-repeat',	'label' => Mage::helper('themesetting')->__('no-repeat')),
            array('value' => 'repeat',		'label' => Mage::helper('themesetting')->__('repeat')),
            array('value' => 'repeat-x',	'label' => Mage::helper('themesetting')->__('repeat-x')),
			array('value' => 'repeat-y',	'label' => Mage::helper('themesetting')->__('repeat-y'))
        );
    }
}