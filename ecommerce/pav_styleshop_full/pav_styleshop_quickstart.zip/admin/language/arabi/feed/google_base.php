<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'Google Base';

// Text   
$_['text_feed']        = 'تغذية المنتجات';
$_['text_success']     = 'تم التعديل!';
$_['text_list']        = 'Layout List';
$_['text_edit']        = 'Edit Google Base';

// Entry
$_['entry_status']     = 'الحالة:';
$_['entry_data_feed']  = 'رابط تغذية المنتجات :<br/><span class="help">ضع هذا الرابط في سيرفر التغذية ويمكنك استخدامه أيضا في موقع ياهو وبنج.</span>:';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل!';
