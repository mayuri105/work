a:8:{i:1;a:8:{s:12:"module_title";a:3:{i:1;s:16:"Banner promotion";i:3;s:16:"Banner promotion";i:4;s:16:"Banner promotion";}s:11:"description";a:3:{i:1;s:1685:"&lt;div class=&quot;media-list clearfix&quot;&gt;
&lt;div class=&quot;wapper-left hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media free&quot;&gt;
&lt;div class=&quot;media-content&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; class=&quot;media-object&quot; src=&quot;image/data/icon-free.png&quot; /&gt; &lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Free Shipping&lt;/h4&gt;

&lt;p&gt;On order over $99.00&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;wapper-center hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media Discount&quot;&gt;
&lt;div class=&quot;media-content&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; class=&quot;media-object&quot; src=&quot;image/data/icon-discounts.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Discount on Orders&lt;/h4&gt;

&lt;p&gt;Tellus aodio consequat odio sed.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;wapper-right hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media need&quot;&gt;
&lt;div class=&quot;media-content&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; class=&quot;media-object&quot; src=&quot;image/data/icon-need.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Need on Help&lt;/h4&gt;

&lt;p&gt;On order over $88.00&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:3;s:1685:"&lt;div class=&quot;media-list clearfix&quot;&gt;
&lt;div class=&quot;wapper-left hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media free&quot;&gt;
&lt;div class=&quot;media-content&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; class=&quot;media-object&quot; src=&quot;image/data/icon-free.png&quot; /&gt; &lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Free Shipping&lt;/h4&gt;

&lt;p&gt;On order over $99.00&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;wapper-center hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media Discount&quot;&gt;
&lt;div class=&quot;media-content&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; class=&quot;media-object&quot; src=&quot;image/data/icon-discounts.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Discount on Orders&lt;/h4&gt;

&lt;p&gt;Tellus aodio consequat odio sed.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;wapper-right hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media need&quot;&gt;
&lt;div class=&quot;media-content&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; class=&quot;media-object&quot; src=&quot;image/data/icon-need.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Need on Help&lt;/h4&gt;

&lt;p&gt;On order over $88.00&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:4;s:1685:"&lt;div class=&quot;media-list clearfix&quot;&gt;
&lt;div class=&quot;wapper-left hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media free&quot;&gt;
&lt;div class=&quot;media-content&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; class=&quot;media-object&quot; src=&quot;image/data/icon-free.png&quot; /&gt; &lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Free Shipping&lt;/h4&gt;

&lt;p&gt;On order over $99.00&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;wapper-center hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media Discount&quot;&gt;
&lt;div class=&quot;media-content&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; class=&quot;media-object&quot; src=&quot;image/data/icon-discounts.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Discount on Orders&lt;/h4&gt;

&lt;p&gt;Tellus aodio consequat odio sed.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;wapper-right hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media need&quot;&gt;
&lt;div class=&quot;media-content&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img alt=&quot;&quot; class=&quot;media-object&quot; src=&quot;image/data/icon-need.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Need on Help&lt;/h4&gt;

&lt;p&gt;On order over $88.00&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:9:"promotion";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"3";}i:2;a:8:{s:12:"module_title";a:3:{i:1;s:18:"Banner Content Top";i:3;s:18:"Banner Content Top";i:4;s:18:"Banner Content Top";}s:11:"description";a:3:{i:1;s:524:"&lt;div class=&quot;row&quot;&gt;
&lt;div class=&quot;col-lg-4 col-md-4 hidden-sm hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner1.jpg&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 hidden-sm hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner2.jpg&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 hidden-sm hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner3.jpg&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;
";i:3;s:524:"&lt;div class=&quot;row&quot;&gt;
&lt;div class=&quot;col-lg-4 col-md-4 hidden-sm hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner1.jpg&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 hidden-sm hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner2.jpg&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 hidden-sm hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner3.jpg&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;
";i:4;s:524:"&lt;div class=&quot;row&quot;&gt;
&lt;div class=&quot;col-lg-4 col-md-4 hidden-sm hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner1.jpg&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 hidden-sm hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner2.jpg&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;col-lg-4 col-md-4 hidden-sm hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner3.jpg&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:8:"showcase";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"1";}i:3;a:8:{s:12:"module_title";a:3:{i:1;s:7:"Call Us";i:3;s:7:"Call Us";i:4;s:7:"Call Us";}s:11:"description";a:3:{i:1;s:373:"&lt;div class=&quot;custom call_us&quot;&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;box-heading small-font&quot;&gt;call us:&lt;/h4&gt;

&lt;p&gt;(+99) 987 654 321&lt;/p&gt;
&lt;/div&gt;
&lt;a class=&quot;text-right&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-phone&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/div&gt;
";i:3;s:373:"&lt;div class=&quot;custom call_us&quot;&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;box-heading small-font&quot;&gt;call us:&lt;/h4&gt;

&lt;p&gt;(+99) 987 654 321&lt;/p&gt;
&lt;/div&gt;
&lt;a class=&quot;text-right&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-phone&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/div&gt;
";i:4;s:373:"&lt;div class=&quot;custom call_us&quot;&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;box-heading small-font&quot;&gt;call us:&lt;/h4&gt;

&lt;p&gt;(+99) 987 654 321&lt;/p&gt;
&lt;/div&gt;
&lt;a class=&quot;text-right&quot; href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-phone&quot;&gt;&amp;nbsp;&lt;/i&gt;&lt;/a&gt;&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:11:"mass_bottom";s:6:"status";s:1:"1";s:12:"module_class";s:7:"call_us";s:10:"sort_order";s:1:"1";}i:4;a:8:{s:12:"module_title";a:3:{i:1;s:9:"Our store";i:3;s:9:"Our store";i:4;s:9:"Our store";}s:11:"description";a:3:{i:1;s:1621:"&lt;div class=&quot;box-content&quot;&gt;
&lt;p&gt;This is Photoshop's version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum&lt;br /&gt;
Sed non mauris vitae erat consequat auctor massa nisl quis neque.&lt;/p&gt;

&lt;ul class=&quot;social&quot;&gt;
	&lt;li&gt;&lt;a class=&quot;facebook&quot; href=&quot;http://facebook.com&quot;&gt;&lt;i class=&quot;fa fa-facebook&quot;&gt;&lt;span&gt;Facebook&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;twitter&quot; href=&quot;http://twitter.com&quot;&gt;&lt;i class=&quot;fa fa-twitter&quot;&gt;&lt;span&gt;Twitter&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;vimeo&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-vimeo-square&quot;&gt;&lt;span&gt;fa-vimeo-square&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;google&quot; href=&quot;https://plus.google.com&quot;&gt;&lt;i class=&quot;fa fa-google-plus&quot;&gt;&lt;span&gt;Google Plus&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;pinterest&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-pinterest&quot;&gt;&lt;span&gt;pinterest&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;skype&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-skype&quot;&gt;&lt;span&gt;Skype&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;square&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-rss-square&quot;&gt;&lt;span&gt;fa-rss-square&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:3;s:1621:"&lt;div class=&quot;box-content&quot;&gt;
&lt;p&gt;This is Photoshop's version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum&lt;br /&gt;
Sed non mauris vitae erat consequat auctor massa nisl quis neque.&lt;/p&gt;

&lt;ul class=&quot;social&quot;&gt;
	&lt;li&gt;&lt;a class=&quot;facebook&quot; href=&quot;http://facebook.com&quot;&gt;&lt;i class=&quot;fa fa-facebook&quot;&gt;&lt;span&gt;Facebook&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;twitter&quot; href=&quot;http://twitter.com&quot;&gt;&lt;i class=&quot;fa fa-twitter&quot;&gt;&lt;span&gt;Twitter&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;vimeo&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-vimeo-square&quot;&gt;&lt;span&gt;fa-vimeo-square&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;google&quot; href=&quot;https://plus.google.com&quot;&gt;&lt;i class=&quot;fa fa-google-plus&quot;&gt;&lt;span&gt;Google Plus&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;pinterest&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-pinterest&quot;&gt;&lt;span&gt;pinterest&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;skype&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-skype&quot;&gt;&lt;span&gt;Skype&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;square&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-rss-square&quot;&gt;&lt;span&gt;fa-rss-square&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:4;s:1621:"&lt;div class=&quot;box-content&quot;&gt;
&lt;p&gt;This is Photoshop's version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum&lt;br /&gt;
Sed non mauris vitae erat consequat auctor massa nisl quis neque.&lt;/p&gt;

&lt;ul class=&quot;social&quot;&gt;
	&lt;li&gt;&lt;a class=&quot;facebook&quot; href=&quot;http://facebook.com&quot;&gt;&lt;i class=&quot;fa fa-facebook&quot;&gt;&lt;span&gt;Facebook&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;twitter&quot; href=&quot;http://twitter.com&quot;&gt;&lt;i class=&quot;fa fa-twitter&quot;&gt;&lt;span&gt;Twitter&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;vimeo&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-vimeo-square&quot;&gt;&lt;span&gt;fa-vimeo-square&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;google&quot; href=&quot;https://plus.google.com&quot;&gt;&lt;i class=&quot;fa fa-google-plus&quot;&gt;&lt;span&gt;Google Plus&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;pinterest&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-pinterest&quot;&gt;&lt;span&gt;pinterest&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;skype&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-skype&quot;&gt;&lt;span&gt;Skype&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;square&quot; href=&quot;#&quot;&gt;&lt;i class=&quot;fa fa-rss-square&quot;&gt;&lt;span&gt;fa-rss-square&lt;/span&gt;&lt;/i&gt;&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:5:"store";s:10:"sort_order";s:1:"1";}i:5;a:8:{s:12:"module_title";a:3:{i:1;s:10:"Contact us";i:3;s:10:"Contact us";i:4;s:10:"Contact us";}s:11:"description";a:3:{i:1;s:534:"&lt;p&gt;If your question is not answeredcontact methods below.&lt;/p&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-map-marker&quot;&gt;&amp;nbsp;&lt;/span&gt;12345 Street name, California, USA&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-mobile-phone&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;(+99) 0123 456 789&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-envelope&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;Email: info@brainos.vn&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:534:"&lt;p&gt;If your question is not answeredcontact methods below.&lt;/p&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-map-marker&quot;&gt;&amp;nbsp;&lt;/span&gt;12345 Street name, California, USA&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-mobile-phone&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;(+99) 0123 456 789&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-envelope&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;Email: info@brainos.vn&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:4;s:534:"&lt;p&gt;If your question is not answeredcontact methods below.&lt;/p&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-map-marker&quot;&gt;&amp;nbsp;&lt;/span&gt;12345 Street name, California, USA&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-mobile-phone&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;(+99) 0123 456 789&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-envelope&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;Email: info@brainos.vn&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:10:"contact-us";s:10:"sort_order";s:1:"1";}i:6;a:8:{s:12:"module_title";a:3:{i:1;s:11:"Information";i:3;s:11:"Information";i:4;s:11:"Information";}s:11:"description";a:3:{i:1;s:465:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Browse Portfolio&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Find a Retailer&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Download Product Fact Sheets&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Browse Tasting Notes&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Browse Points of Distinction&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:465:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Browse Portfolio&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Find a Retailer&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Download Product Fact Sheets&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Browse Tasting Notes&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Browse Points of Distinction&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:4;s:465:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Browse Portfolio&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Find a Retailer&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Download Product Fact Sheets&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Browse Tasting Notes&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Browse Points of Distinction&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:6:"column";s:10:"sort_order";s:1:"2";}i:7;a:8:{s:12:"module_title";a:3:{i:1;s:10:"My account";i:3;s:10:"My account";i:4;s:10:"My account";}s:11:"description";a:3:{i:1;s:453:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Grape Glossary&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Food Pairing &amp;amp; Servings Tips&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Mixology&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Education Video Gallery&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Ask the Expert&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:453:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Grape Glossary&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Food Pairing &amp;amp; Servings Tips&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Mixology&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Education Video Gallery&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Ask the Expert&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:4;s:453:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Grape Glossary&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Food Pairing &amp;amp; Servings Tips&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Mixology&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Education Video Gallery&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot;&gt;Ask the Expert&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:6:"column";s:10:"sort_order";s:1:"3";}i:8;a:8:{s:12:"module_title";a:3:{i:1;s:13:"Banner Footer";i:3;s:13:"Banner Footer";i:4;s:13:"Banner Footer";}s:11:"description";a:3:{i:1;s:145:"&lt;div style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner-footer.jpg&quot; /&gt;&lt;/div&gt;
";i:3;s:145:"&lt;div style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner-footer.jpg&quot; /&gt;&lt;/div&gt;
";i:4;s:145:"&lt;div style=&quot;text-align: center;&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner/banner-footer.jpg&quot; /&gt;&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_bottom";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";i:1;}}