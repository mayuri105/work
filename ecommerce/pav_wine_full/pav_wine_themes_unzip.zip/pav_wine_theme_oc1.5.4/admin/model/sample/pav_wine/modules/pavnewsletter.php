a:1:{i:1;a:5:{s:9:"layout_id";s:5:"99999";s:8:"position";s:11:"mass_bottom";s:6:"status";s:1:"1";s:10:"sort_order";s:1:"2";s:11:"description";a:3:{i:1;s:48:"&lt;p&gt;Tellus aodio consequat seo.&lt;/p&gt;
";i:3;s:46:"&lt;p&gt;Tellus aodio consequat seo.&lt;/p&gt;";i:4;s:48:"&lt;p&gt;Tellus aodio consequat seo.&lt;/p&gt;
";}}}