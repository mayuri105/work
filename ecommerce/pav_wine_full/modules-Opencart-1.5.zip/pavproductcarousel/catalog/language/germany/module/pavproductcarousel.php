<?php
// Heading 
$_['heading_title'] = 'Neueste';

//Text
$_['text_latest'] = 'Neueste';
$_['text_mostviewed'] = 'Meist gesehen';
$_['text_featured'] = 'Feature';
$_['text_bestseller'] = 'Best Seller';
$_['text_special'] = 'Special';

$_['text_sale'] = 'Sale';
$_['text_sale_detail'] = 'Speichern:% s';
?>
