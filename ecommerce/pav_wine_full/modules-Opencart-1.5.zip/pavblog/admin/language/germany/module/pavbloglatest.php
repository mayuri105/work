<?php
// Heading
$_['heading_title'] = '<span style="color:#E1653B"> Pav Blog Neueste Modul </ span >';

// Text
$_['text_module'] = ' Module ';
$_['text_success'] = 'Erfolg: Du hast Diashow -Modul geändert ';
$_['text_content_top'] = 'Content Top' ;
$_['text_content_bottom'] = 'Content- Bottom ';
$_['text_column_left'] = ' Spalte links ';
$_['text_column_right'] = ' Spalte rechts ';
$_['text_mainmenu'] = ' Hauptmenü ';
$_['text_slideshow'] = ' Slideshow ';
$_['text_promotion'] = ' Promotion ';
$_['text_bottom1'] = ' Bottom 1';
$_['text_bottom2'] = ' Bottom 2';
$_['text_bottom3'] = ' Bottom 3';
$_['text_mass_bottom'] = 'Mass Bottom ';
$_['text_footer_top'] = ' Footer Top' ;
$_['text_footer_center'] = ' Footer -Center ';
$_['text_footer_bottom'] = ' Footer Bottom ';
$_['all_page'] = ' Alle Seite ';
// Eintrag
$_['entry_banner'] = ' Banner :';
$_['entry_dimension'] = ' Abmessungen (B x H) and Resize Typ :';
$_['entry_layout'] = 'Layout :';
$_['entry_position'] = ' Position: ';
$_['entry_status'] = ' Status: ';
$_['entry_sort_order'] = ' Sortierung :';
$_['entry_carousel'] = ' Max Columns - Limitpositionen In Carousel :';
$_['Entry_tabs'] = ' Produkt Tab Types ';
$_['Entry_description'] = ' Modul Beschreibung ';


$_['text_latest'] = ' Neueste' ;
$_['text_mostviewed'] = ' Meist gesehen ';
$_['text_featured'] = ' Feature ';
$_['text_bestseller'] = ' Best Seller ';
$_['text_special'] = ' Special' ;
$_['button_blog_management'] = ' Blog Management' ;
// Fehler
$_['error_permission'] = ' Achtung: Sie haben keine Berechtigung zum Modul Diashow zu ändern ';
$_['error_dimension'] = ' Breite und Höhe Abmessungen erforderlich! ';
$_['error_carousel'] = ' Breite & Max Items - Max Columns - Limitpositionen In Carousel erforderlich ';

?>
