<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Tex
$_['text_footer'] = ' دعم <a href="http://www.opencart.com" target="_blank">OpenCart</a> &copy; 2009 - ' . date('Y') . ' جميع الحقوق محفوظة<br />ترجمة <a href="http://www.opencartarab.com" target="_blank">OpenCartArab</a><br />الاصدار رقم<br />%s';
$_['text_version'] 	= 'Version %s';