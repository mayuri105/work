<?php 

$_['text_sale'] = 'Sale';
$_['text_sale_detail'] = 'Save: %s';
?>