a:1:{i:1;a:5:{s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:10:"sort_order";s:1:"5";s:11:"description";s:231:"&lt;p&gt;&lt;label for=&quot;Sign Up for Our Newsletter&quot;&gt;Sign Up for Our Newsletter:&lt;/label&gt;&lt;/p&gt;

&lt;p&gt;Get the word out Share this page with your friends and family. Enter your email address...&lt;/p&gt;
";}}