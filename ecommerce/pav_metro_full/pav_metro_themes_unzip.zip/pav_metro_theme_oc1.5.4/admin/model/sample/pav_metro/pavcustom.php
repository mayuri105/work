a:8:{i:1;a:9:{s:12:"module_title";a:2:{i:1;s:7:"Welcome";i:4;s:7:"Welcome";}s:11:"description";a:2:{i:1;s:790:"&lt;div class=&quot;pav-block-welcome&quot;&gt;
&lt;p class=&quot;pav-arrow-left hidden-phone hidden-tablet&quot;&gt;&amp;nbsp;&lt;/p&gt;

&lt;p class=&quot;pav-arrow-right hidden-phone hidden-tablet&quot;&gt;&amp;nbsp;&lt;/p&gt;

&lt;div class=&quot;row-fluid&quot;&gt;
&lt;div class=&quot;span7&quot;&gt;
&lt;div class=&quot;pav-block-left&quot;&gt;
&lt;h2&gt;Welcome to Metro Store&lt;/h2&gt;

&lt;p&gt;Morbi felis ligula scelerisque id ullamcorper fermentum adipiscing donec ac molestie metus.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;span5&quot;&gt;
&lt;div class=&quot;pav-block-right&quot;&gt;&lt;a class=&quot;btn&quot; href=&quot;#&quot; title=&quot;By theme now&quot;&gt;By Theme now&lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:4;s:790:"&lt;div class=&quot;pav-block-welcome&quot;&gt;
&lt;p class=&quot;pav-arrow-left hidden-phone hidden-tablet&quot;&gt;&amp;nbsp;&lt;/p&gt;

&lt;p class=&quot;pav-arrow-right hidden-phone hidden-tablet&quot;&gt;&amp;nbsp;&lt;/p&gt;

&lt;div class=&quot;row-fluid&quot;&gt;
&lt;div class=&quot;span7&quot;&gt;
&lt;div class=&quot;pav-block-left&quot;&gt;
&lt;h2&gt;Welcome to Metro Store&lt;/h2&gt;

&lt;p&gt;Morbi felis ligula scelerisque id ullamcorper fermentum adipiscing donec ac molestie metus.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;span5&quot;&gt;
&lt;div class=&quot;pav-block-right&quot;&gt;&lt;a class=&quot;btn&quot; href=&quot;#&quot; title=&quot;By theme now&quot;&gt;By Theme now&lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";}s:8:"store_id";a:1:{i:0;s:1:"0";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:9:"slideshow";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"2";}i:2;a:9:{s:12:"module_title";a:2:{i:1;s:13:"Free Shipping";i:4;s:13:"Free Shipping";}s:11:"description";a:2:{i:1;s:174:"&lt;div class=&quot;pav-block-shipping&quot;&gt;&lt;img alt=&quot;Free Shipping&quot; src=&quot;catalog/view/theme/pav_metro/image/free-shipping.png&quot; /&gt;&lt;/div&gt;
";i:4;s:174:"&lt;div class=&quot;pav-block-shipping&quot;&gt;&lt;img alt=&quot;Free Shipping&quot; src=&quot;catalog/view/theme/pav_metro/image/free-shipping.png&quot; /&gt;&lt;/div&gt;
";}s:8:"store_id";a:1:{i:0;s:1:"0";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:9:"promotion";s:6:"status";s:1:"1";s:12:"module_class";s:17:"pav-free-shipping";s:10:"sort_order";s:1:"1";}i:3;a:9:{s:12:"module_title";a:2:{i:1;s:8:"Sale Off";i:4;s:8:"Sale Off";}s:11:"description";a:2:{i:1;s:152:"&lt;div class=&quot;pav-block-sale&quot;&gt;&lt;img alt=&quot;Sale&quot; src=&quot;catalog/view/theme/pav_metro/image/sale.png&quot; /&gt;&lt;/div&gt;
";i:4;s:152:"&lt;div class=&quot;pav-block-sale&quot;&gt;&lt;img alt=&quot;Sale&quot; src=&quot;catalog/view/theme/pav_metro/image/sale.png&quot; /&gt;&lt;/div&gt;
";}s:8:"store_id";a:1:{i:0;s:1:"0";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:9:"promotion";s:6:"status";s:1:"1";s:12:"module_class";s:12:"pav-sale-off";s:10:"sort_order";s:1:"2";}i:4;a:9:{s:12:"module_title";a:2:{i:1;s:6:"Spring";i:4;s:6:"Spring";}s:11:"description";a:2:{i:1;s:158:"&lt;div class=&quot;pav-block-spring&quot;&gt;&lt;img alt=&quot;Spring&quot; src=&quot;catalog/view/theme/pav_metro/image/spring.png&quot; /&gt;&lt;/div&gt;
";i:4;s:158:"&lt;div class=&quot;pav-block-spring&quot;&gt;&lt;img alt=&quot;Spring&quot; src=&quot;catalog/view/theme/pav_metro/image/spring.png&quot; /&gt;&lt;/div&gt;
";}s:8:"store_id";a:1:{i:0;s:1:"0";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:9:"promotion";s:6:"status";s:1:"1";s:12:"module_class";s:10:"pav-spring";s:10:"sort_order";s:1:"3";}i:5;a:9:{s:12:"module_title";a:2:{i:1;s:18:"Our Special Offers";i:4;s:18:"Our Special Offers";}s:11:"description";a:2:{i:1;s:991:"&lt;div class=&quot;pav-special-offers&quot;&gt;
&lt;h3&gt;&lt;span&gt;Our &lt;/span&gt; Special Offers&lt;/h3&gt;

&lt;div class=&quot;row-fluid&quot;&gt;
&lt;div class=&quot;span4&quot;&gt;
&lt;div class=&quot;pav-block-spring-collection clearfix&quot;&gt;&lt;img alt=&quot;Spring Collection&quot; class=&quot;pull-left&quot; src=&quot;catalog/view/theme/pav_metro/image/spring-collection.png&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;span4&quot;&gt;
&lt;div class=&quot;pav-block-extra clearfix&quot;&gt;&lt;img alt=&quot;All Products&quot; class=&quot;pull-left&quot; src=&quot;catalog/view/theme/pav_metro/image/extra.png&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;span4&quot;&gt;
&lt;div class=&quot;pav-block-new-collection clearfix&quot;&gt;&lt;img alt=&quot;New Collection&quot; class=&quot;pull-left&quot; src=&quot;catalog/view/theme/pav_metro/image/new-collection.png&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:4;s:991:"&lt;div class=&quot;pav-special-offers&quot;&gt;
&lt;h3&gt;&lt;span&gt;Our &lt;/span&gt; Special Offers&lt;/h3&gt;

&lt;div class=&quot;row-fluid&quot;&gt;
&lt;div class=&quot;span4&quot;&gt;
&lt;div class=&quot;pav-block-spring-collection clearfix&quot;&gt;&lt;img alt=&quot;Spring Collection&quot; class=&quot;pull-left&quot; src=&quot;catalog/view/theme/pav_metro/image/spring-collection.png&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;span4&quot;&gt;
&lt;div class=&quot;pav-block-extra clearfix&quot;&gt;&lt;img alt=&quot;All Products&quot; class=&quot;pull-left&quot; src=&quot;catalog/view/theme/pav_metro/image/extra.png&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;span4&quot;&gt;
&lt;div class=&quot;pav-block-new-collection clearfix&quot;&gt;&lt;img alt=&quot;New Collection&quot; class=&quot;pull-left&quot; src=&quot;catalog/view/theme/pav_metro/image/new-collection.png&quot; /&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";}s:8:"store_id";a:1:{i:0;s:1:"0";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:11:"mass_bottom";s:6:"status";s:1:"1";s:12:"module_class";s:14:"special_offers";s:10:"sort_order";s:1:"1";}i:6;a:9:{s:12:"module_title";a:2:{i:1;s:14:"Static Content";i:4;s:14:"Static Content";}s:11:"description";a:2:{i:1;s:869:"&lt;div class=&quot;pav-content-bottom&quot;&gt;
&lt;div class=&quot;row-fluid&quot;&gt;
&lt;div class=&quot;span3&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;catalog/view/theme/pav_metro/image/static3.png&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;span7&quot;&gt;
&lt;h3&gt;100 kindle fire hd &lt;span&gt;$3.99&lt;/span&gt; or less&lt;/h3&gt;

&lt;p&gt;Nunc gavida nisl utrices loborti molis temp tempor quam congue turpis sed psum blandit donec vitae laoreet vestibulum lobortis mattis sapien bero cursus congue urna mauris.&lt;/p&gt;
&lt;/div&gt;

&lt;div class=&quot;span2&quot;&gt;&lt;a class=&quot;circlehover with-symbol&quot; data-align=&quot;right&quot; data-position=&quot;top-left&quot; data-size=&quot;&quot; href=&quot;#&quot;&gt;&lt;span class=&quot;text&quot;&gt;Find out more&lt;/span&gt; &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:4;s:869:"&lt;div class=&quot;pav-content-bottom&quot;&gt;
&lt;div class=&quot;row-fluid&quot;&gt;
&lt;div class=&quot;span3&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;catalog/view/theme/pav_metro/image/static3.png&quot; /&gt;&lt;/div&gt;

&lt;div class=&quot;span7&quot;&gt;
&lt;h3&gt;100 kindle fire hd &lt;span&gt;$3.99&lt;/span&gt; or less&lt;/h3&gt;

&lt;p&gt;Nunc gavida nisl utrices loborti molis temp tempor quam congue turpis sed psum blandit donec vitae laoreet vestibulum lobortis mattis sapien bero cursus congue urna mauris.&lt;/p&gt;
&lt;/div&gt;

&lt;div class=&quot;span2&quot;&gt;&lt;a class=&quot;circlehover with-symbol&quot; data-align=&quot;right&quot; data-position=&quot;top-left&quot; data-size=&quot;&quot; href=&quot;#&quot;&gt;&lt;span class=&quot;text&quot;&gt;Find out more&lt;/span&gt; &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";}s:8:"store_id";a:1:{i:0;s:1:"0";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:14:"content_bottom";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"3";}i:7;a:9:{s:12:"module_title";a:2:{i:1;s:9:"Socialize";i:4;s:9:"Socialize";}s:11:"description";a:2:{i:1;s:888:"&lt;div class=&quot;pav-social&quot;&gt;
&lt;h3&gt;&lt;span&gt;Socialize&lt;/span&gt;&lt;/h3&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;a class=&quot;facebook&quot; href=&quot;#&quot; title=&quot;Facebook&quot;&gt;Facebook&lt;/a&gt; &lt;a class=&quot;twitte&quot; href=&quot;#&quot; title=&quot;&quot;&gt;Twitte&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;dribbble&quot; href=&quot;#&quot; title=&quot;Dribbble&quot;&gt;Dribbble&lt;/a&gt; &lt;a class=&quot;vimeo&quot; href=&quot;#&quot; title=&quot;&quot;&gt;Vimeo&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;google&quot; href=&quot;#&quot; title=&quot;Google plus&quot;&gt;Google plus&lt;/a&gt; &lt;a class=&quot;email&quot; href=&quot;#&quot; title=&quot;&quot;&gt;Email&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;rss&quot; href=&quot;#&quot; title=&quot;Rss&quot;&gt;Rss&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:4;s:888:"&lt;div class=&quot;pav-social&quot;&gt;
&lt;h3&gt;&lt;span&gt;Socialize&lt;/span&gt;&lt;/h3&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;a class=&quot;facebook&quot; href=&quot;#&quot; title=&quot;Facebook&quot;&gt;Facebook&lt;/a&gt; &lt;a class=&quot;twitte&quot; href=&quot;#&quot; title=&quot;&quot;&gt;Twitte&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;dribbble&quot; href=&quot;#&quot; title=&quot;Dribbble&quot;&gt;Dribbble&lt;/a&gt; &lt;a class=&quot;vimeo&quot; href=&quot;#&quot; title=&quot;&quot;&gt;Vimeo&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;google&quot; href=&quot;#&quot; title=&quot;Google plus&quot;&gt;Google plus&lt;/a&gt; &lt;a class=&quot;email&quot; href=&quot;#&quot; title=&quot;&quot;&gt;Email&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a class=&quot;rss&quot; href=&quot;#&quot; title=&quot;Rss&quot;&gt;Rss&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";}s:8:"store_id";a:1:{i:0;s:1:"0";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:10:"pav_social";s:10:"sort_order";s:1:"1";}i:8;a:9:{s:12:"module_title";a:2:{i:1;s:8:"About us";i:4;s:8:"About us";}s:11:"description";a:2:{i:1;s:795:"&lt;div class=&quot;pav-about&quot;&gt;
&lt;h3&gt;&lt;span&gt;About us&lt;/span&gt;&lt;/h3&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Dolor sit amet&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Nam cursus nunc&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Fermentum&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Consequat&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Morbi mauris&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Praesent felis&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Molestie nec nibh&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";i:4;s:795:"&lt;div class=&quot;pav-about&quot;&gt;
&lt;h3&gt;&lt;span&gt;About us&lt;/span&gt;&lt;/h3&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Dolor sit amet&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Nam cursus nunc&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Fermentum&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Consequat&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Morbi mauris&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Praesent felis&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;Molestie nec nibh&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
";}s:8:"store_id";a:1:{i:0;s:1:"0";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:12:"pav-about-us";s:10:"sort_order";s:1:"2";}}