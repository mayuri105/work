a:8:{i:1;a:8:{s:12:"module_title";a:2:{i:1;s:8:"About Us";i:2;s:11:"من نحن";}s:11:"description";a:2:{i:1;s:774:"&lt;div class=&quot;address&quot;&gt;
&lt;p&gt;&lt;span&gt;Praesent quis ante dapibus tellus mollis dapibus ullamcorper sit amet erat. &lt;/span&gt;&lt;/p&gt;

&lt;div class=&quot;box-addres&quot;&gt;
&lt;div class=&quot;link-address icon&quot;&gt;&lt;span class=&quot;fa fa-map-marker&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;span&gt;No 1104 Sky Tower, Newyork, USA&lt;/span&gt;&lt;/div&gt;

&lt;div class=&quot;link-mobile icon&quot;&gt;&lt;span class=&quot;fa fa-phone&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;span&gt;Phone: +01 888 (000) 1234&lt;/span&gt;&lt;/div&gt;

&lt;div class=&quot;link-mail icon&quot;&gt;&lt;span class=&quot;fa fa-envelope&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;span&gt;Email: support@gmail.com&lt;/span&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:2;s:522:"&lt;address&gt;
&lt;p&gt;&lt;span&gt;Praesent quis ante dapibus tellus mollis dapibus ullamcorper sit amet erat. &lt;/span&gt;&lt;/p&gt;

&lt;p class=&quot;link-address fa fa-map-marker&quot;&gt;&lt;span&gt;No 1104 Sky Tower, Newyork, USA &lt;/span&gt;&lt;/p&gt;

&lt;p class=&quot;link-mobile fa fa-phone&quot;&gt;&lt;span&gt;(123) 456-7890&lt;/span&gt;&lt;/p&gt;

&lt;p class=&quot;link-mail fa fa-envelope-o&quot;&gt;&lt;a href=&quot;mailto:#&quot;&gt;pavothemes@gmail.com&lt;/a&gt;&lt;/p&gt;
&lt;/address&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";i:5;}i:2;a:8:{s:12:"module_title";a:2:{i:1;s:11:"information";i:2;s:12:"الحساب";}s:11:"description";a:2:{i:1;s:453:"&lt;ul class=&quot;list-style&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;About&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;Order History&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;Wish List&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=checkout/cart&quot;&gt;My Cart&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:2;s:740:"&lt;ul class=&quot;list-style&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;حسابي&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;أجل التاريخ&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;قائمة المفضلة&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;النشرة الإخبارية&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;?route=pavblog/blogs&quot;&gt;بلوق&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;last&quot;&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;العروض الخاصة&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"2";}i:3;a:8:{s:12:"module_title";a:2:{i:1;s:15:"img-Bestsellers";i:2;s:15:"img-Bestsellers";}s:11:"description";a:2:{i:1;s:229:"&lt;div class=&quot;banner effect hidden-md hidden-sm hidden-sx&quot;&gt;&lt;img alt=&quot;banner1&quot; class=&quot;img-responsive&quot; src=&quot;image/data/banner/banner1.jpg&quot; title=&quot;banner3&quot; /&gt;&lt;/div&gt;
";i:2;s:192:"&lt;div class=&quot;effect&quot;&gt;&lt;img alt=&quot;banner1&quot; class=&quot;img-responsive&quot; src=&quot;image/data/banner/banner1.jpg&quot; title=&quot;banner3&quot; /&gt;&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:8:"showcase";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"2";}i:4;a:8:{s:12:"module_title";a:2:{i:1;s:7:"Support";i:2;s:6:"دعم";}s:11:"description";a:2:{i:1;s:361:"&lt;ul class=&quot;list-style&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/manufacturer&quot;&gt;Manufacturer&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Voucher&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;Special&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:2;s:412:"&lt;ul class=&quot;list-style&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/manufacturer&quot;&gt;العلامات التجارية&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;قسائم هدية&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;العروض الخاصة&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"3";}i:5;a:8:{s:12:"module_title";a:2:{i:1;s:8:"Category";i:2;s:6:"فئة";}s:11:"description";a:2:{i:1;s:367:"&lt;ul class=&quot;list-style&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;Newsletter&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;?route=pavblog/blogs&quot;&gt;Blog&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;last&quot;&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;Specials&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:2;s:409:"&lt;ul class=&quot;list-style&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;النشرة الإخبارية&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;?route=pavblog/blogs&quot;&gt;بلوق&lt;/a&gt;&lt;/li&gt;
	&lt;li class=&quot;last&quot;&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;العروض الخاصة&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"2";}i:6;a:8:{s:12:"module_title";a:2:{i:1;s:5:"About";i:2;s:5:"About";}s:11:"description";a:2:{i:1;s:343:"&lt;p&gt;&lt;img alt=&quot;logo-about&quot; class=&quot;img-responsive logo-about&quot; src=&quot;image/data/logo.png&quot; /&gt;&lt;/p&gt;

&lt;p class=&quot;description-about&quot;&gt;Aliquam viverra magna ac enim pharetra cursus. Praesent quis ante dapibus tellus mollis dapibus ullamcorper sit amet erat.Aliquam viverra magna&lt;/p&gt;
";i:2;s:416:"&lt;p&gt;&lt;img alt=&quot;logo-about&quot; class=&quot;img-responsive logo-about&quot; src=&quot;image/data/logo.png&quot; /&gt;&lt;/p&gt;

&lt;p class=&quot;description-about&quot;&gt;Aliquam viverra magna ac enim pharetra cursus. Praesent quis ante dapibus tellus mollis dapibus ullamcorper sit amet erat.Aliquam viverra magna ac enim pharetra cursus. Praesent quis ante dapibus tellus mollis dapibu&lt;/p&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"1";}i:7;a:8:{s:12:"module_title";a:2:{i:1;s:8:"banner-1";i:2;s:8:"banner-1";}s:11:"description";a:2:{i:1;s:193:"&lt;div class=&quot;effect&quot;&gt;&lt;img alt=&quot;banner1&quot; class=&quot;img-responsive&quot; src=&quot;image/data/banner/banner-1.jpg&quot; title=&quot;banner2&quot; /&gt;&lt;/div&gt;
";i:2;s:193:"&lt;div class=&quot;effect&quot;&gt;&lt;img alt=&quot;banner1&quot; class=&quot;img-responsive&quot; src=&quot;image/data/banner/banner-1.jpg&quot; title=&quot;banner2&quot; /&gt;&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:8:"showcase";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"3";}i:8;a:8:{s:12:"module_title";a:2:{i:1;s:12:"banner-botom";i:2;s:12:"banner-botom";}s:11:"description";a:2:{i:1;s:198:"&lt;div class=&quot;effect&quot;&gt;&lt;img alt=&quot;banner1&quot; class=&quot;img-responsive&quot; src=&quot;image/data/banner/banner-bottom.jpg&quot; title=&quot;banner2&quot; /&gt;&lt;/div&gt;
";i:2;s:198:"&lt;div class=&quot;effect&quot;&gt;&lt;img alt=&quot;banner1&quot; class=&quot;img-responsive&quot; src=&quot;image/data/banner/banner-bottom.jpg&quot; title=&quot;banner2&quot; /&gt;&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:8:"mass_top";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"1";}}