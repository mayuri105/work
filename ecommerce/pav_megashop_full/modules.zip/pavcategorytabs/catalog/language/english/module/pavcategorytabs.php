<?php
/******************************************************
 * @package Pav Category Tabs module for Opencart 1.5.x
 * @version 1.0
 * @author http://www.pavothemes.com
 * @copyright	Copyright (C) Feb 2012 PavoThemes.com <@emai:pavothemes@gmail.com>.All rights reserved.
 * @license		GNU General Public License version 2
*******************************************************/
// Heading 
$_['heading_title'] = 'Latest';

// Text
$_['text_latest']  = 'Latest'; 
$_['text_mostviewed']  = 'Most Viewed 2'; 
$_['text_featured']  = 'Featured'; 
$_['text_bestseller']  = 'Best Seller'; 
$_['text_special']  = 'Special';
$_['text_sale'] = 'Sale';
$_['text_related']  = 'Related';
?>