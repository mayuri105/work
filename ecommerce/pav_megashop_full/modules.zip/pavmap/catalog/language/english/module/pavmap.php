<?php
/******************************************************
 * @package Pav Map module for Opencart 1.5.x
 * @version 1.0
 * @author http://www.pavothemes.com
 * @copyright	Copyright (C) Feb 2012 PavoThemes.com <@emai:pavothemes@gmail.com>.All rights reserved.
 * @license		GNU General Public License version 2
*******************************************************/
// Heading
$_['heading_title']       = 'Pav Map';

$_['text_view_more']      = 'VIEW MORE';

?>