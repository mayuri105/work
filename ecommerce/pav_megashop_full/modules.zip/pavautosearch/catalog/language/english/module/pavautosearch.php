<?php
$_['text_viewall'] = 'View all %s items';
$_['text_category_all'] = 'All Category';
$_['text_all_manufacturer'] = 'All Manufacturer';
$_['text_pavautosearch_title'] = 'Search Suggestion';
$_['text_submit_search'] = 'Search';
$_['text_search'] = 'Search..';
$_['text_price'] = 'Price';
$_['text_view_all'] = 'View all %s items';