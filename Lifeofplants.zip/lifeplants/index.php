
<?php
	 require('config/dbconfig.php');
	 require_once('geoplugin.class.php');
	 require_once('season.php');
	 require_once('weather.php');


	 $geoplugin = new geoPlugin();
	 $geoplugin->locate();
	 date_default_timezone_set("Australia/Brisbane"); 
 ?>
<!DOCTYPE html> 
<html>
<head>
	<title>Life Of Plants</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="shortcut icon" href="https://www.gardeningknowhow.com/gkh-16.png">
	<script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script> 
	
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<style type="text/css">
		.clear{

			clear: both;
		}

		
		.info {
		  background-color: #e7f3fe;
		  border-left: 6px solid #56CC9D;
		}
		/* width */
		::-webkit-scrollbar {
		  width: 20px;
		}

		/* Track */
		::-webkit-scrollbar-track {
		  /*box-shadow: inset 0 0 5px grey; */
		  border-radius: 10px;
		  background-color: transparent;
		  
		}
		 
		/* Handle */
		::-webkit-scrollbar-thumb {
		  background: #56CC9D; 
		  border-radius: 10px;
		  border:1px solid white;
		}
 
		/* Handle on hover */
		::-webkit-scrollbar-thumb:hover {
		  background: #20c997; 
		  
     
		}
		/*body{

			background: url(image/background.jpg) no-repeat;
			background-attachment: fixed;
			background-size: 100% 100%;

		}*/
		.btn1 {
		  padding: 0.5rem 1rem;
		  font-size: 1.25rem;
		  line-height: 1.5;
		  border-bottom: 3px solid white;
		  border-radius: 0.6rem;
		}
		.btn1:hover {
		  padding: 0.5rem 1rem;
		  font-size: 1.25rem;
		  line-height: 1.5;
		  border-bottom: 3px solid black;
		  transition: 1s;  
		  border-radius: 0.6rem;
		}
		.list-group-item{
			color: #000!important;

		}
	</style>
	 <script type="text/javascript">
$(document).ready(function(){
    $('#genera').on('change',function(){
        var countryID = $(this).val();
        
              if(countryID){ 
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'country_id='+countryID,
                success:function(html){
                    $('#Species').html(html);                    
                }
            }); 
        }else{
            $('#Species').html('<option value="">Select Genera first</option>');
             
        }
    });
     
  $('#genera').on('change',function(){
        var countryID1 = $(this).val();
        
              if(countryID1){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'country_id1='+countryID1,
                success:function(html){
                    
			        $('.description').html(html);

                }
            }); 
        }else{
                    $('.description').html('<h1>Select Genera First</h1>'); 
            
            }
    });
      
    
});
</script>
	</head> 
	<body>
	
	<div class="bg-primary p-3 container-fluid col-sm-12">
  		<h1 class="text-center"> <a href="index.php"> <img src="image/logo.png"></a></h1>
		
	</div>


	<div class="container-fluid">
	<div class="row">
		<div class="col-sm-3 border-right mt-3">
			<div class="card ml-0 mr-0 p-0 text-white bg-primary mb-3">
				  	<div class="btn1 text-center">TODAY'S <span style="background:white;padding:5px; color:black;border-radius:15px;text-transform: uppercase;"><?php echo $data->name."'S"; ?></span> WEATHER STATUS</div>
				  	<div class="card-body">
					    <ul class="list-group font-weight-bold">
				  			 <li class="list-group-item d-flex justify-content-between align-items-center">
							    Time 
							    <span class="badge badge-primary badge-pill"><?php echo date("H:i:s A") ?></span>
							 </li>
							 <li class="list-group-item d-flex justify-content-between align-items-center">
							    Day 
							    <span class="badge badge-primary badge-pill"><?php echo date("  l  "); ?></span>
							 </li>
							 <li class="list-group-item d-flex justify-content-between align-items-center">
							    Date 
							    <span class="badge badge-primary badge-pill"><?php echo date(' d-F-Y '); ?></span>
							 </li>
				  			 <li class="list-group-item d-flex justify-content-between align-items-center">
							   Weather  
							    <span class="badge badge-primary badge-pill"><?php echo ucwords($data->weather[0]->description); ?></span>
							    <img src="http://openweathermap.org/img/w/<?php echo $data->weather[0]->icon; ?>.png" class="weather-icon" />
							 </li>
							 <li class="list-group-item d-flex justify-content-between align-items-center">
							    Max-Temp 
							    <span class="badge badge-primary badge-pill"><?php echo $data->main->temp_max; ?>&deg;C</span>
							 </li>
							 <li class="list-group-item d-flex justify-content-between align-items-center">
							    Min-Temp 
							    <span class="badge badge-primary badge-pill"><?php echo $data->main->temp_min; ?>&deg;C</span>
							 </li>
							 <li class="list-group-item d-flex justify-content-between align-items-center">
							   Humidity 
							    <span class="badge badge-primary badge-pill"><?php echo $data->main->humidity; ?> %</span>
							 </li>
							 <li class="list-group-item d-flex justify-content-between align-items-center">
							    Wind 
							    <span class="badge badge-primary badge-pill"><?php echo $data->wind->speed; ?> km/h</span>
							 </li>
							 <li class="list-group-item d-flex justify-content-between align-items-center">
							    Clouds
							    <span class="badge badge-primary badge-pill"><?php echo $data->clouds->all; ?>%</span>
							 </li>	
							 <?php 
										$apiKey = "ca62d8027da96a47f3a0d828753e8479";
										$cityId = $geoplugin->city;
						 	?>
 						<a href="http://api.openweathermap.org/data/2.5/weather?q=<?php echo  $cityId;?>&lang=en&mode=html&units=metric&APPID=<?php echo $apiKey; ?>" target="_blank" class="badge badge-pill mt-3 badge-dark p-3"	>Get Weather</a>					 
						</ul>
					</div>
				</div>
				<div class="card ml-0 mr-0 p-0 text-white bg-primary mb-3">
			 	<div class="btn1 text-center">SEASON</div>
			  	<div class="card-body">			    
				  	<li class="list-group-item text-primary d-flex justify-content-between align-items-center text-center">				   
				    <span style="display:block;width:100%;padding:15px; color: black;  margin: 0px auto;"  class=" text-center badge badge-primary badge-pill">
				    	<?php
				  		$date = date('d-m-Y');
				  		
				    	$season = get_season($date , "australia"); 
				    	echo $season;
				    	?>				    
				    </span>
				    </li>				
			    </div> 
			</div>
				<div class="card text-white bg-primary mb-3" >
			    <div class="btn1 text-center">LOCATION DETAILS</div>
			 	<div class="card-body">			
			 		<ul class="list-group font-weight-bold">
						<li class="list-group-item text-primary d-flex justify-content-between align-items-center">		
				    	<span style="display:block;width:100%;padding:15px;color:black;  margin: 0px auto;" class="badge badge-primary badge-pill"><?php echo " ".$geoplugin->city.", ".$geoplugin->region  ?></span>
				    	<!-- <span>Hill End Terrace, Brisbane West End, Queensland, 4101
West End Brisbane Australia</span> -->
				  		</li>				   				 
					</ul>
			    </div>
			</div>
			</div><!-- first column end -->
			<div class="col-sm-9">
					<h1 class="text-center">Select Your Plant</h1>			
				<div class="row border-radius border-top">
					<div class="col-sm-3 border-bottom border-right" style="border-radius: 15px;">
			  				
			  				<div class="form-group">
			     				<label for="exampleSelect1">Genera</label>
							         <select class="form-control" name="genera" id="genera"  >	
							        <?php
							        	 
							        $query = mysqli_query($db_handle,"select * from genera");
										if(mysqli_num_rows($query)>=1){
                                            echo '<option value="1" selected>Lithops</option>';
											
											while($val = mysqli_fetch_array($query)){
												?>
			 				        	<!-- <option value="<?php echo $val['id'] ?>"><?php echo $val['generaname'] ?></option> -->
							        	<?php		
                                         echo '<option  value="1">'.$val['generaname'].'</option>';

							        		}
							        	}else{	 						        ?>		       
										<option value="">No data Found</option>
										<?php
											}
										?>	<!-- drop down of lithops -->		 
							        </select>    
			    			</div>
			      			
					      	<div class="form-group">
					      		<label for="exampleSelect1">Species</label>				     
					      			 <select class="form-control" name="Species" id="Species">
								        <option value="">Select Genera first</option>
								    </select>
								    <!-- dropdown of spicies -->					    
					    	</div>
			      			<div class="form-group">
							    <label for="exampleSelect1">Age </label>
							        <select class="form-control" name="age" id="age">
								        
								        <option value="1" selected>Adult</option>
								        <option value="2">Seedling</option>

								    </select>     
						    </div>
					      	<!-- drrop down of age -->
						    <!-- <div class="form-group">
						    <div id="sdf"></div>
						    </div> -->

						</div><!-- second column end -->
		<div class="col-sm-9" >
			<h3 class="text-center">
				How To Take Care Of Lithops.?
			</h3>
			<div class="mr-3 container border" style="height: 500px; overflow-y: scroll; border-radius: 15px;">
				<p class="text-justify description">
				
<!-- description on selecting lithops -->
					
				
				</p>
			</div>					 
		</div><!-- third column end -->
	</div><!-- second  and third column row end here -->
	<div class="clear"></div>
			<div class="container border mt-3 mt-3" style="border-radius: 15px;">
				<h2>Current Health Status Of Lithops.</h2>
				<div class="row" id="imagegrid"> 
					<!-- images shown regarding seaseon and spicies -->
				</div>
			</div>
		<!-- <a href="index.php" class="badge badge-dark p-3 mt-3 mb-3" style="float: right;">Next</a> -->
	</div>

		</div><!-- main row -->
	</div><!-- container end -->
</body>
</html>