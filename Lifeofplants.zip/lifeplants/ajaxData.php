<?php
//Include database configuration file
include('config/dbConfig.php');
require_once('season.php');

 
if(isset($_POST["country_id"]) && !empty($_POST["country_id"])){
    $id= $_POST["country_id"];
    $query = mysqli_query($db_handle,"SELECT * FROM `plants` WHERE `generaid`=".$id."");

                                        if(mysqli_num_rows($query)>=1){
                                            echo '<option value="" selected>Select Species</option>';

                                            while($val = mysqli_fetch_array($query)){
                                                ?>

                                        <!-- <option value="<?php echo $val['id'] ?>"><?php echo $val['lifespan'] ?></option> -->
                                        <?php   
                                         echo '<option  value="'.$val['generaid'].'">'.$val['plantname'].'</option>';

                                            }
                                        }else{                                  ?>             
                                        <option value="" class="info">No Species Data Found</option>
                                        <?php
                                        
                                            }
                        /*dropdown of spicies usin genera id*/
                                             
}


if(isset($_POST["country_id1"]) && !empty($_POST["country_id1"])){
    $id= $_POST["country_id1"];
   
    $date = date('d-m-Y');
                        
                        $s = get_season($date , "australia"); 
                        $season =  ucfirst(trim($s));

     $query = mysqli_query($db_handle,"SELECT * FROM `care` WHERE `generaid`=".$id."  AND season ='".$season."' ");
                                if(mysqli_num_rows($query)>=1){
                                            while($val = mysqli_fetch_array($query)){
                                                ?>
                     <!-- description of lithops on select dropdown value -->   
                                            

  <div class="card mb-3" style=" background-color: #343a40;color:white!important;box-shadow: 0 12px 10px -7px rgba(0,0,0,0.1);">
                
                                    <h3 class="card-header text-center"><h1 class="text-center border-bottom">Your Selected Genera Details</h1></h3>
                                  <h3 class="card-header text-center" >
                                    <?php 

                                        $name = mysqli_query($db_handle,"Select * from genera where id =".$val['generaid']."");
                                            $generaname = mysqli_fetch_array($name);
                                            echo "Genera Name : ".$generaname['generaname'];


                                     ?></h3>
                                
                                  <div class="card-body">
                                    <p class="card-text p-3 text-justify" style="background-color: #343a40;" ><?php echo $val['description']; ?></p>
                                  </div>
                                  
                               
                                               

                                            <?php
                                            }
                                        }else{                                  ?>             
                                        <h1 class="text-center info"> No palnt Data Found For This Season </h1>
                                        <?php
                                            }              
}
?> 

