// JavaScript Document
 
var xmlHttp1

function iopp(str1)
{ 

xmlHttp1=GetXmlHttpObject1();
if (xmlHttp1==null)
  {
  alert ("Your browser does not support AJAX!");
  return;
  } 
var url="<?php echo base_url();?>index.php/Welcome/getdata";
url=url+"?sendid="+str1;
url=url+"&srid="+Math.random();
xmlHttp1.onreadystatechange=stateChanged3;
xmlHttp1.open("GET",url,true);
xmlHttp1.send(null);
}

function stateChanged3() 
{ 
if (xmlHttp1.readyState==4)
{ 
document.getElementById("sdf").innerHTML=xmlHttp1.responseText;

}
}
 
function GetXmlHttpObject1()
{
var xmlHttp1=null;
try
  {
  // Firefox, Opera 8.0+, Safari
  xmlHttp1=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    xmlHttp1=new ActiveXObject("Msxml2.XMLHTTP1");
    }
  catch (e)
    {
    xmlHttp1=new ActiveXObject("Microsoft.XMLHTTP1");
    }
  }
return xmlHttp1;
}